from django.apps import AppConfig


class SignupformConfig(AppConfig):
    name = 'signupform'
