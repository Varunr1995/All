from django.shortcuts import render, redirect
from django.contrib.auth.models import User, auth
from django.contrib import messages

# Create your views here.

def signupform(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        email = request.POST['email']
        contactnumber = request.POST['contactnumber']
        country = request.POST['country']
        username = request.POST['username']
        password = request.POST['password']
        password1 = request.POST['password1']
        
        if password==password1:
            if User.objects.filter(username=username).exists():
                messages.info(request,"User Name is already in use")
                return redirect('signupform')
            elif User.objects.filter(email=email).exists():
                messages.info(request, "A person is already registered with this address")
                return redirect('signupform')
            else:
                user = User.objects.create_user(username=username, password=password, first_name=first_name, last_name=last_name, email=email)
                user.save()
                messages.info(request, 'user created')
        else:
            messages.info(request, 'password is not matching')    
            return redirect('signupform')
        return redirect('/')
    
    else:
           return render(request, "signupform.html")