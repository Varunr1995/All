from django.db import models

# Create your models here.

class User_Registration(models.Model):
    First_Name = models.CharField(max_length=100, null=False) 
    Last_Name = models.CharField(max_length=100, null=False)
    Contact_Number = models.IntegerField(null=False)
    Email_id = models.EmailField(null=False)
    Country = models.CharField(max_length=10, null=False)
    UserName = models.CharField(max_length=100, null=False)
    Password = models.CharField(max_length=50, null=False)
    Confirm_Password = models.CharField(max_length=50, null=False)

