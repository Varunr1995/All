# ecommerce-django
Simple Ecommerce website built using Django


https://ekluv.herokuapp.com/


Checkout this repo, install dependencies, then start the server:

    > git clone https://github.com/Ekluv/ecommerce-django.git
    > cd ecommerce-django
    > virtualenv .
    > source bin/activate
    > cd src
    > pip install -r requirements.txt
    > python manage.py runserver
    
    
    
